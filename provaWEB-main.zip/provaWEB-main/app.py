from flask import Flask, render_template
from lanches import Lanches
from apresentacao import Info
app = Flask(__name__)

info = Info("Lanchonete","Olá, somos a cantina universitária. Estamos começando a trabalhar nesta instituição e só temos esses 4 lanches no momento.")

x_burguer = Lanches("X-burguer"," aqui, está é o x-burguer com apenas 3 ingredientes pao, carne e queijo", "img/x-burguer.jpeg", 1)
x_bacon = Lanches("X-bacon"," aqui, está é o x-bacon com apenas 6 ingredientes pao, carne, queijo, alface, tomate e bacon", "img/x-bacon.jpeg", 2)
x_salada = Lanches("X-salada"," aqui, está é o x-salada com apenas 6 ingredientes pao, carne, queijo, alface, tomate e molho da casa", "img/x-salada.jpeg", 3)
x_tudo = Lanches("X-tudo"," aqui, está é o x-tudo com apenas 7 ingredientes pao, carne, queijo, alface, tomate, bacon e ovo", "img/x-tudo.jpeg", 4)
x_lanches = [x_burguer,x_bacon,x_salada,x_tudo]

@app.route('/')
def index():
    return render_template('index.html', lanches=x_lanches,info = info)

@app.route('/lanches/<int:id:int>')
def infolanches(id:int):
    for lanche in x_lanches:
        if lanche.id == id:
            return render_template('infolanches.html',xlanche=lanche)
    return "<h1>Ops! Curso não encontrado!</h1>"

if __name__ == '__main__':
    app.run(debug=True)
